# COMUNICA
- Leonardo de Paiva Junior
- Maria Eduarda Carvalho de Meneses
- Pedro Piva Soares Ribeiro
- Samuel Reis da Costa
- Vinicius Rocha de Vasconcellos

